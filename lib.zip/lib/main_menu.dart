import 'package:flutter/material.dart';
import '/Models/main_menu_buttons.dart';

class MainMenu extends StatelessWidget {
  const MainMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("Menu"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Call Even Split Button

          // Call Individual Button
          MainMenuButtons(
            text: "Separate Meal",
            icon: Icons.person,
            onPressed: () {
              Navigator.pushNamed(context, '/individualMeal');
            },
            color: Colors.green.shade200,
          ),

          const SizedBox(
            height: 20,
          ),

          MainMenuButtons(
            text: "Group Meal",
            icon: Icons.people,
            onPressed: () {
              Navigator.pushNamed(context, '/groupMeal');
            },
            color: Colors.blue.shade100,
          ),

          const SizedBox(
            height: 20,
          ),

          // MainMenuButtons(text: "Owe Money Record", icon: Icons.attach_money, onPressed: (){}, color: Colors.green,),
        ],
      ),
    );
  }
}
